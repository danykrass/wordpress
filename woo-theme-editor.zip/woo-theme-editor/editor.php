<?php

/*
Plugin Name: Theme Settings plugin
Plugin URI: https://github.com/danykrass/wordpress
Description: A brief description of the Plugin.
License: GNU GENERAL PUBLIC LICENSE
Version: 1.0
Author: DanyKrass
Author URI: http://danykrass.com
License: A "Slug" license name e.g. GPL2
*/

require_once 'functions.php';
add_action('admin_menu', 'register_woo_form_editor');
function register_woo_form_editor()
{
    add_menu_page(
        'Theme settings', 'Theme settings', 'manage_options', 'theme-settings', 'woo_form_editor', plugins_url('assets/css/style.css', __FILE__), 6
    );
}
function woo_form_editor_styles() {
    wp_enqueue_style( 'ThemeStylesheet', plugins_url('assets/css/style.css', __FILE__) );
}
function woo_form_editor()
{
    $arrInfo = [
        [$_POST['currency_symbol'],'woocommerce_currency_symbol'], [$_POST['position'], 'woocommerce_currency_pos'],
        [$_POST['woo_form_font-color'], 'woo_form_font-color'], [$_POST['woo_form_font-size'], 'woo_form_font-size'],
        [$_POST['woo_form_font-font-family'], 'woo_form_font-font-family'], [$_POST['woo_form_color-price-symbol'], 'woo_form_color-price-symbol'],
        [$_POST['woo_form_size-price-symbol'], 'woo_form_size-price-symbol'], [$_POST['woo_form_font-family-price-symbol'], 'woo_form_font-family-price-symbol'],
    ];

    foreach ($arrInfo as $info) updateInfo($info[0], $info[1]);

    if (!get_option('woo_form_font-color') || !get_option('woo_form_font-size') || !get_option('woo_form_font-font-family')) {

        $arrOptions = [
            'woo_form_font-color', 'woo_form_font-size', 'woo_form_font-family',
            'woo_form_color-price-symbol', 'woo_form_size-price-symbol', 'woo_form_font-family-price-symbol',
        ];
        foreach ($arrOptions as $option) add_option($option,'', '', 'no');
    }


    include (__DIR__ . '/index.php');

}

add_filter('woocommerce_currency_symbol', 'new_symbol', 10, 2);
function new_symbol($price_symbol, $price_code)
{
    $currency_symbol = get_woocommerce_currency();
    if ($price_code == $currency_symbol) {
        return get_option('woocommerce_currency_symbol');
    }
    return $price_symbol;
}
add_action("wp_head", 'script_columns', 10 );
add_action("admin_head", 'script_columns', 10);
function script_columns() {
    ?>
    <style type="text/css">
        #wpcontent {
            padding: 0 !important;
        }
        .woocommerce-Price-currencySymbol{
            color: <?php echo get_option('woo_form_color-price-symbol') ?>;
            font-size: <?php echo get_option('woo_form_size-price-symbol').'px' ?>;
            font-family: <?php echo get_option('woo_form_font-family-price-symbol') ?>;
        }
        .woocommerce-Price-amount {
            font-family: <?php echo get_option('woo_form_font-font-family') ?>;
            font-size: <?php echo get_option('woo_form_font-size').'px'?>;
            color: <?php echo get_option('woo_form_font-color')?>;
        }
    </style>
    <?php
}
