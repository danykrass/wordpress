let isPaused = false;

window.addEventListener("load", () => {

    const timeEl = document.getElementById('time')

    localStorage.setItem('seconds', 0)

    setInterval(() => {

        let seconds = Number(localStorage.getItem('seconds'))
        const date = new Date(0);

        date.setSeconds(seconds);

        const timeString = date.toISOString().substr(11, 8);

        if (!isPaused) {
            localStorage.setItem('seconds', seconds + 1)
        }

        timeEl.innerText = timeString
    }, 1000);
});

window.addEventListener('onunload', () => {
    localStorage.removeItem('seconds')
})

document.addEventListener("visibilitychange", function (e) {
    isPaused = document.hidden
});

