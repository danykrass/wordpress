<?php

$adminName = get_admin_page_title();
$currency_symbol = get_woocommerce_currency_symbol();
$currency_position = get_option('woocommerce_currency_pos');
$style = plugins_url('assets/css/style.css', __FILE__);
$scripts = plugins_url('assets/js/main.js', __FILE__);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge"/>
    <title><?php wp_title(); ?></title>
    <link rel="stylesheet" href="<?php echo $style; ?>">
</head>
<body>
<!-- <span id="time"></span> -->
<div class="settings__page">
    <h1 class="title">Настройка темы</h1>
    <form action='' method='post'>
        <div class="currency_info">
            <span id="time"></span>
            <p>Валюта: <?php echo get_option('woocommerce_currency') ?></p>
            <p>Символ валюты: <?php echo $currency_symbol ?> </p>
            <p>Шрифт цены: <span class="woocommerce-Price-amount"><?php echo get_option('woo_form_font-font-family') ?></span></p>
            <p>Шрифт символа: <span class="woocommerce-Price-currencySymbol"><?php echo get_option('woo_form_font-family-price-symbol') ?></span></p>
        </div>
        <h2>Настройка символа валюты</h2>
        <div class="form__group">
            <input type="input" class="form__field" placeholder="<?php echo $currency_symbol ?>" name="currency_symbol"
                   id='currency_symbol'/>
            <label for="currency_symbol" class="form__label">Нажмите чтобы изменить символ</label>
        </div>
        <label for="slct">Расположение символа</label>
        <div class="select">
            <select name="position" id="slct">
                <option selected disabled><?php echo $currency_position ?></option>
                <option value="left">Слева от цены</option>
                <option value="right">Справа от цены</option>
            </select>
        </div>

        <div class="form__group">
            <input type="input" class="form__field" placeholder="Symbol color" name="woo_form_color-price-symbol"
                   id="symbol_color"/>
            <label for="symbol_color" class="form__label">Изменить цвет</label>
        </div>
        <div class="form__group">
            <input type="input" class="form__field" placeholder="Symbol font size" name="woo_form_size-price-symbol"
                   id="symbol_font_size"/>
            <label for="symbol_font_size" class="form__label">Изменить размер шрифта</label>
        </div>
        <label for="woo_form_font-family-price-symbol">Выберете шрифта</label>
        <div class="select" id="woo_form_font-family-price-symbol">
            <select name="woo_form_font-family-price-symbol" id="woo_form_font-family-price-symbol">
                <option selected disabled><?php echo get_option('woo_form_font-family-price-symbol') ?></option>
                <option value="Arial,Tahoma,sans-serif">Arial, Tahoma, sans-serif</option>
                <option value="Roboto,sans-serif">Roboto, sans-serif</option>
            </select>
        </div>
        <h2>Настройка валюты</h2>
        <div class="form__group">
            <input type="input" class="form__field" placeholder="Price color" name="woo_form_font-color"
                   id="price_color"/>
            <label for="price_color" class="form__label">Изменить цвет</label>
        </div>
        <div class="form__group">
            <input type="input" class="form__field" placeholder="Price font size" name="woo_form_font-size"
                   id="price_font_size"/>
            <label for="price_font_size" class="form__label">Изменить размер шрифта</label>
        </div>
        <label for="woo_form_font-font-family">Выберете шрифт</label>
        <div class="select">
            <select name="woo_form_font-font-family" id="woo_form_font-font-family">
                <option selected disabled><?php echo get_option('woo_form_font-font-family') ?></option>
                <option value="Arial,Tahoma,sans-serif">Arial, Tahoma, sans-serif</option>
                <option value="Roboto,sans-serif">Roboto, sans-serif</option>
            </select>
        </div>

        <button type='submit'>Применить настройки</button>
    </form>
</div>
<script src="<?php echo $scripts?>"></script>
</body>

</html>