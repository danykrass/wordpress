<?php


function updateInfo($value, string $stringSQL)
{
    if ($value) {
        update_option($stringSQL, $value, false);
    }
}
